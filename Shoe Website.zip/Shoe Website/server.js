require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");

const app = express();
const PORT = process.env.PORT || 2200;

// ===== MIDDLEWARE =====
app.use(bodyParser.json());
app.use(express.json());
app.use(express.static("public"));

// ===== FILE PATHS =====
const logsDir = path.join(__dirname, "user_logs");
const usersFile = path.join(__dirname, "users.json");

// Ensure logs folder exists
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir);

// ===== HELPER FUNCTIONS =====
const readUsers = () => (fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile, "utf8")) : []);
const writeUsers = (users) => fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));

const sanitizeFilename = (email) => email.replace(/[^a-z0-9]/gi, "_").toLowerCase();

const writeUserLog = (email, data) => {
  const fileName = sanitizeFilename(email) + ".json";
  const filePath = path.join(logsDir, fileName);
  let logs = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath, "utf8")) : [];
  logs.push(data);
  fs.writeFileSync(filePath, JSON.stringify(logs, null, 2));
  return fileName;
};

const parseUserAgent = (uaString) => {
  if (!uaString) return { browser: "Unknown", device: "Unknown" };
  const ua = uaString.toLowerCase();

  let browser = ["chrome", "firefox", "safari", "edg", "opera", "opr"].find(b => ua.includes(b)) || "Unknown";
  browser = browser === "opr" ? "Opera" : browser.charAt(0).toUpperCase() + browser.slice(1);

  let device = "Other";
  if (ua.includes("mobile")) device = "Mobile";
  else if (ua.includes("windows")) device = "Windows PC";
  else if (ua.includes("mac")) device = "Mac";
  else if (ua.includes("android")) device = "Android";
  else if (ua.includes("linux")) device = "Linux";

  return { browser, device };
};

const logUserAttempt = (email, req, success) => {
  const { browser, device } = parseUserAgent(req.headers["user-agent"]);
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
  const now = new Date();

  const logData = { email, time: now.toLocaleString(), browser, device, ip, success };
  const fileName = writeUserLog(email, logData);

  console.log(`
==========================================
🕒 ${logData.time}
📧 Email: ${email}
🌐 Browser: ${browser}
💻 Device: ${device}
📡 IP: ${ip}
✅ Login ${success ? "Successful" : "Failed"}
📁 Saved to: user_logs/${fileName}
==========================================
`);
  return logData;
};

// ===== EMAIL SETUP =====
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,   // Set in .env
    pass: process.env.EMAIL_PASS,   // Gmail app password
  },
});

const otpStore = {}; // Temporary OTP storage

// ===== ROUTES =====

// --- Home ---
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "home.html")));
app.get("/index.html", (req, res) => res.redirect("/"));

// --- Register ---
app.post("/register", (req, res) => {
  const { username, email, password } = req.body;
  const users = readUsers();

  if (users.some(u => u.email === email)) return res.status(400).json({ message: "User already exists" });

  users.push({ username, email, password });
  writeUsers(users);
  res.json({ message: "Registration successful" });
});

// --- Login ---
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const users = readUsers();
  const user = users.find(u => u.email === email && u.password === password);

  logUserAttempt(email, req, !!user);
  if (!user) return res.status(401).json({ message: "Invalid credentials" });

  res.json({ message: "Login successful", username: user.username });
});

// --- Password Reset Flow ---
app.post("/request-reset", (req, res) => {
  const { email } = req.body;
  const users = readUsers();
  const user = users.find(u => u.email === email);
  if (!user) return res.status(404).json({ message: "User not found" });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  otpStore[email] = { otp, expires: Date.now() + 5 * 60 * 1000 };

  transporter.sendMail({
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Password Reset OTP",
    text: `Your OTP is ${otp}. It expires in 5 minutes.`,
  }, (err) => {
    if (err) return res.status(500).json({ message: "Failed to send OTP" });
    res.json({ message: "OTP sent successfully" });
  });
});

app.post("/reset-password", (req, res) => {
  const { email, otp, newPassword } = req.body;
  const stored = otpStore[email];

  if (!stored) return res.status(400).json({ message: "No OTP requested" });
  if (stored.otp !== otp) return res.status(400).json({ message: "Invalid OTP" });
  if (Date.now() > stored.expires) return res.status(400).json({ message: "OTP expired" });

  const users = readUsers();
  const index = users.findIndex(u => u.email === email);
  if (index === -1) return res.status(404).json({ message: "User not found" });

  users[index].password = newPassword;
  writeUsers(users);

  delete otpStore[email];
  res.json({ message: "Password updated successfully" });
});

// --- View User Logs ---
app.get("/user-logs", (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ message: "Email required" });

  const fileName = sanitizeFilename(email) + ".json";
  const filePath = path.join(logsDir, fileName);
  if (!fs.existsSync(filePath)) return res.status(404).json({ message: "No logs found for this user" });

  const logs = JSON.parse(fs.readFileSync(filePath, "utf8"));
  res.json({ email, logs });
});

// ===== START SERVER =====
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));