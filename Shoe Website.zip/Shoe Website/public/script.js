// ================== UTILS ==================
function showNotification(message, type = "info", duration = 3000) {
  const container = document.getElementById("dynamic-island-container");
  if (!container) return;

  const notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.innerText = message;

  container.appendChild(notification);

  requestAnimationFrame(() => notification.classList.add("show"));

  setTimeout(() => {
    notification.classList.remove("show");
    setTimeout(() => notification.remove(), 200);
  }, duration);
}

// ================== AUTH ==================
async function registerUser() {
  const username = document.getElementById("username")?.value.trim();
  const email = document.getElementById("email")?.value.trim();
  const password = document.getElementById("password")?.value.trim();

  if (!username || !email || !password) {
    return showNotification("All fields are required!", "error");
  }

  try {
    const res = await fetch("/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password }),
    });

    const data = await res.json();
    if (res.ok) {
      showNotification("User successfully added!", "success");
      setTimeout(() => (window.location = "login.html"), 1500);
    } else {
      showNotification(data.message, "error");
    }
  } catch (err) {
    showNotification("Server error. Try again later!", "error");
    console.error(err);
  }
}

async function loginUser() {
  const email = document.getElementById("email")?.value.trim();
  const password = document.getElementById("password")?.value.trim();

  if (!email || !password) {
    return showNotification("Both fields required!", "error");
  }

  try {
    const res = await fetch("/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (res.ok) {
      localStorage.setItem(
        "loggedUser",
        JSON.stringify({ email, username: data.username })
      );
      showNotification("Login successful!", "success");
      setTimeout(() => (window.location = "home.html"), 1500);
    } else {
      showNotification(data.message, "error");
    }
  } catch (err) {
    showNotification("Server error. Try again later!", "error");
    console.error(err);
  }
}

function logoutUser() {
  localStorage.removeItem("loggedUser");
  window.location = "login.html";
}

function checkLogin() {
  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  if (!loggedUser) return (window.location = "login.html");
  document.getElementById("userName").innerText = loggedUser.username;
}

// ================== PASSWORD RESET ==================
async function requestReset() {
  const email = document.getElementById("resetEmail")?.value.trim();
  if (!email) return showNotification("Enter your email!", "error");

  try {
    const res = await fetch("/request-reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const data = await res.json();
    if (res.ok) {
      showNotification("OTP sent to your email!", "success");
      document.getElementById("otpSection").style.display = "block";
    } else {
      showNotification(data.message, "error");
    }
  } catch (err) {
    showNotification("Server error. Try again later!", "error");
    console.error(err);
  }
}

async function resetPassword() {
  const email = document.getElementById("resetEmail")?.value.trim();
  const otp = document.getElementById("otp")?.value.trim();
  const newPassword = document.getElementById("newPassword")?.value.trim();

  if (!otp || !newPassword) {
    return showNotification("All fields required!", "error");
  }

  try {
    const res = await fetch("/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, otp, newPassword }),
    });

    const data = await res.json();
    if (res.ok) {
      showNotification("Password reset successful!", "success");
      setTimeout(() => (window.location = "login.html"), 1500);
    } else {
      showNotification(data.message, "error");
    }
  } catch (err) {
    showNotification("Server error. Try again later!", "error");
    console.error(err);
  }
}

// ================== NAVBAR ==================
const links = document.querySelectorAll(".navbar a");
const current = window.location.pathname.split("/").pop();
links.forEach((link) => {
  if (link.getAttribute("href") === current) link.classList.add("active");
});