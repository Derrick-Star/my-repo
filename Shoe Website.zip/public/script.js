// ================== REGISTER ==================
async function registerUser() {
  const username = document.getElementById("username").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!username || !email || !password) {
    alert("All fields are required");
    return;
  }

  const res = await fetch("/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  });

  const data = await res.json();
  alert(data.message);

  if (res.ok) window.location = "login.html";
}

// ================== LOGIN ==================
async function loginUser() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!email || !password) {
    alert("Both fields required");
    return;
  }

  const res = await fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  alert(data.message);

  if (res.ok) {
    // Save user to localStorage
    localStorage.setItem("loggedUser", JSON.stringify({
      email: email,
      username: data.username
    }));
    window.location = "index.html";
  }
}

// ================== LOGOUT ==================
function logoutUser() {
  localStorage.removeItem("loggedUser");
  window.location = "login.html";
}

// ================== CHECK LOGIN ==================
function checkLogin() {
  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  if (!loggedUser) {
    window.location = "login.html";
  } else {
    document.getElementById("userName").innerText = loggedUser.username;
  }
}
// ---------- POPUP FUNCTION ----------
function showPopup(message, duration = 3000) {
  const popup = document.getElementById("popup");
  popup.innerText = message;
  popup.classList.add("show");

  setTimeout(() => {
    popup.classList.remove("show");
  }, duration);
}

// ================== REGISTER ==================
async function registerUser() {
  const username = document.getElementById("username").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!username || !email || !password) {
    showPopup("All fields are required!");
    return;
  }

  const res = await fetch("/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  });

  const data = await res.json();
  showPopup(data.message);

  if (res.ok) window.location = "login.html";
}

// ================== LOGIN ==================
async function loginUser() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!email || !password) {
    showPopup("Both fields required!");
    return;
  }

  const res = await fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  
  if (res.ok) {
    localStorage.setItem("loggedUser", JSON.stringify({
      email: email,
      username: data.username
    }));
    showPopup("Login successful!", 1500);
    setTimeout(() => window.location = "index.html", 1500);
  } else {
    showPopup(data.message);
  }
}

// ================== REGISTER ==================
async function registerUser() {
  const username = document.getElementById("username").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!username || !email || !password) {
    showNotification("All fields are required!", "error");
    return;
  }

  const res = await fetch("/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  });

  const data = await res.json();
  if (res.ok) {
    showNotification("User successfully added!", "success");
    setTimeout(() => window.location = "login.html", 1500);
  } else {
    showNotification(data.message, "error");
  }
}

// ================== LOGIN ==================
async function loginUser() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!email || !password) {
    showNotification("Both fields required!", "error");
    return;
  }

  const res = await fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  
  if (res.ok) {
    localStorage.setItem("loggedUser", JSON.stringify({
      email: email,
      username: data.username
    }));
    showNotification("Login successful!", "success");
    setTimeout(() => window.location = "index.html", 1500);
  } else {
    showNotification(data.message, "error");
  }
}

// ---------------- Dynamic Island Notification ----------------
function showNotification(message, type = "info", duration = 3000) {
  const container = document.getElementById("dynamic-island-container");
  if (!container) return;

  const notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.innerText = message;

  container.appendChild(notification);

  // Animate in
  requestAnimationFrame(() => {
    notification.classList.add("show");
  });

  // Remove after duration
  setTimeout(() => {
    notification.classList.remove("show");
    setTimeout(() => container.removeChild(notification), 500);
  }, duration);
}