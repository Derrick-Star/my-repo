const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = 2525;

app.use(express.json());
app.use(express.static("public"));

// Register user
app.post("/register", (req, res) => {
  const filePath = path.join(__dirname, "users.json");
  let users = [];

  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath);
    users = JSON.parse(data);
  }

  const { username, email, password } = req.body;
  const userExists = users.some(u => u.email === email);

  if (userExists) {
    return res.status(400).json({ message: "User already exists" });
  }

  users.push({ username, email, password });
  fs.writeFileSync(filePath, JSON.stringify(users, null, 2));
  res.json({ message: "Registration successful" });
});

// Login user
app.post("/login", (req, res) => {
  const filePath = path.join(__dirname, "users.json");
  if (!fs.existsSync(filePath)) {
    return res.status(400).json({ message: "No users found" });
  }

  const users = JSON.parse(fs.readFileSync(filePath));
  const { email, password } = req.body;

  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    res.json({ message: "Login successful", username: user.username });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

// Password reset request (fake link generation)
app.post("/forgot-password", (req, res) => {
  const { email, newPassword } = req.body;
  const filePath = path.join(__dirname, "users.json");

  if (!fs.existsSync(filePath)) return res.status(400).json({ message: "No users found" });

  const users = JSON.parse(fs.readFileSync(filePath));
  const userIndex = users.findIndex(u => u.email === email);

  if (userIndex === -1) return res.status(404).json({ message: "User not found" });

  users[userIndex].password = newPassword; // simple reset
  fs.writeFileSync(filePath, JSON.stringify(users, null, 2));

  res.json({ message: "Password successfully reset!" });
});

app.post("/register", (req, res) => {
  console.log("Register request received:", req.body);
  ...
});
app.post("/login", (req, res) => {
  console.log("Login request received:", req.body);
  ...
});